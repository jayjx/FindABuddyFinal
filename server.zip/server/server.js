const express = require('express');
const mysql = require('mysql');
const app = express();
var bodyParser = require('body-parser');
var methodOvereide = require('method-override');
var cors = require('cors');
app.use(cors());
app.use(bodyParser.json());
app.use(methodOvereide());
const allowedOrigins = [
'capacitor://localhost',
'ionic://localhost',
'http://localhost',
'http://localhost:8080',
'http://localhost:8100'
];

const corsOptions = {
    origin: (origin, callback) => {
    if (allowedOrigins.includes(origin) || !origin) {
    callback(null, true);
    } else {
    callback(new Error('Origin not allowed by CORS'));
    }
    }
    }
    app.options('*', cors(corsOptions));
    const db = mysql.createPool({
    connectionLimit: 100,
    host: '182.50.133.92',
    user: 'team2',
    password: 'team2pwd',
    database: 'Team2'
    });
    
    app.get('/', cors(corsOptions), (req, res, next) => {
        res.json({ message: 'This is Buddy.' });
        })

    //get newsfeeds
    app.route('/NewsFeeds', cors(corsOptions)).get(function (request, response) {    
    var idNewsFeeds = request.body.idNewsFeeds;
    var userID = request.body.userID;
    db.query('SELECT * FROM NewsFeeds WHERE userID = ? order by idNewsFeeds desc;',[idNewsFeeds,userID],
    function (error, result, fields) {
    if (error) {
    console.log('Error message: ', error);
    throw error;
    };
    
    console.log(result)
    response.send(result);
    //sent all item details
    })
    })

    //insert newsfeeds
    app.route('/Addnewsfeeds', cors(corsOptions)).post(function (request, response) {
        var title = request.body.title;
        var caption = request.body.caption;
        var picture = request.body.picture;
        var createdate = request.body.createdate;
        var editdate = request.body.editdate;
        // Insert Item
        db.query('INSERT Into Team2.NewsFeeds (title, caption, picture, create_date, edit_date) values (?,?,?,?,?) ;',
        [title, caption, picture, createdate, editdate], function
        (error, result, fields) {
            if (!error) {
                console.log(result);
                response.send(true)
            } else {
                console.log(error);
                response.send(false)
            }
        })
    })

    // delete newsfeeds
    app.route('/Deletenewsfeeds', cors(corsOptions)).post(function (request, response) {
        var idNewsFeeds = request.body.idNewsFeeds;
        db.query('Delete FROM Team2.NewsFeeds WHERE idNewsFeeds = ? ;', [idNewsFeeds], 
        function (error, result, fields) {
            if (!error) {
                console.log(result);
                response.send(true)
            } else {
                console.log(error);
                response.send(false)
            }
          })
    })

    //get 1 newsfeeds
    app.route('/1NewsFeeds', cors(corsOptions)).post(function (request, response) {
        var idNewsFeeds = request.body.idNewsFeeds
        db.query('SELECT title,caption,picture,create_date,edit_date,userID FROM Team2.NewsFeeds WHERE idNewsFeeds = ? and userID = ? order by idNewsFeeds desc;', [idNewsFeeds,userID],
        function (error, result, fields) {
        if (!error) {
            if (result.length > 0) {
                response.send(result);
                } else {
                    response.send(false);
                    }
                        } else {
                        console.log(error);
                        throw error
                    }
                })
            })

    app.route('/Editnewsfeeds', cors(corsOptions)).post(function (request, response) {
        var idNewsFeeds = request.body.idNewsFeeds
        var title = request.body.title;
        var caption = request.body.caption;
        var picture = request.body.picture;
        var createdate = request.body.createdate;
        var editdate = request.body.editdate;
    // edit Item
    db.query('UPDATE Team2.NewsFeeds set title=?, caption=?,picture=?, create_date=?,edit_date=? where idNewsFeeds =? and userID =? ;',
    [title, caption, picture, createdate, editdate, idNewsFeeds, userID],function 
    (error, result, fields) {
    if (!error) {
    console.log(result);
    response.send(true)
        } else {
        console.log(error);
        response.send(false)
        }
     })
})

//login authentication 
    app.route('/authentication', cors(corsOptions))
    .post(function (request, response) {
        var EMAIL = request.body.email;
        var PASSWORD = request.body.password
        db.query('SELECT userID FROM Team2.UserAccount where email = ? and password = ?;', [EMAIL, PASSWORD], function (error, result, fields) {
            if (error) {
                console.log('Error message: ', error);
                throw error;
            };
            console.log(result)
            response.send(result);
            //send all details
        })
    });

    db.getConnection((err1) => {
    console.log('Connecting mySQL....')
    if (err1) {
    throw err1;
    }

    
    db.query('select * from NewsFeeds;', function (err2, result, field) {
    if (!err2) {
    console.log(result);
    }
    else {
    console.log(err2)
    }
    });
    });
    // Basic things to include
    app.set('port', process.env.PORT || 3000);

    app.listen(app.get('port'), function () {   
    console.log("listening to Port", app.get("port"));
    });
    console.log('Mysql connected....')

    
    


    
    