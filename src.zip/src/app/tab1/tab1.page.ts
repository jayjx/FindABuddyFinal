import { Component } from '@angular/core';
import { Storage } from '@capacitor/storage';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  id:string
  
  constructor(private router:ActivatedRoute) {
    this.id = this.router.snapshot.params.id;
  }
  
  ngOnInit() {
    this.loginUser()
  }

  async loginUser() {
    const { value } = await Storage.get({ key: 'userID' });
    console.log('Got item: ', value);
    this.id = value;
    console.log("userid:",this.id)
}}
