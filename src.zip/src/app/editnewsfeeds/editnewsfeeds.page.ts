import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup} from '@angular/forms';
import { NewsfeedsService } from '../shared/services/newsfeeds.service';
import { ActivatedRoute, RouterEvent } from '@angular/router';
import { Router } from '@angular/router';
import { FileUploadService } from '../file-upload.service'
import { DatePipe, formatDate } from '@angular/common';
import { Storage } from '@capacitor/storage';
@Component({
  selector: 'app-editnewsfeeds',
  templateUrl: './editnewsfeeds.page.html',
  styleUrls: ['./editnewsfeeds.page.scss'],
})
export class EditnewsfeedsPage implements OnInit {
  idNewsFeeds: any;
  arr: any = {};
  editnewsfeeds: any = [];
  submitted: boolean;
  picture:File | null = null;;
  source:string;
  filename:string;
  fileToUpload: File | null = null;
  // Variable to store shortLink from api response
  shortLink: string = "";
  loading: boolean = false; // Flag variable
  file: File = null; // Variable to store file
  //date
  currentDate = new Date();
  id:string;
  constructor(public http: HttpClient, public newsfeedService: NewsfeedsService,public route: ActivatedRoute,public router: Router,
    private fileUploadService: FileUploadService) { 
    this.idNewsFeeds = this.route.snapshot.params.idNewsFeeds;
    this.editnewsfeeds = new FormGroup({
      title: new FormControl(''),
      caption: new FormControl(''),
      picture: new FormControl(''),
      createdate: new FormControl(new Date),
      editdate: new FormControl(new Date),
      userid: new FormControl(''),
      });
  }
  
  ngOnInit() {
    console.log("editpage", this.idNewsFeeds)
    this.get1newsfeeds()
    
    }
    async loginUser() {
      const { value } = await Storage.get({ key: 'userID' });
      console.log('Got item: ', value);
      this.id = value;
      console.log("userid:",this.id)
    }

    get1newsfeeds() {
    var url = 'https://buddyfind.herokuapp.com/1NewsFeeds';
    var get1newsfeeds = JSON.stringify({
    idNewsFeeds : this.idNewsFeeds
    });


    const httpOptions = {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,HEAD,PUT,PATCH,POST,DELETE'
      })
    };

    this.http.post(url, get1newsfeeds, httpOptions).subscribe((data) => {
    console.log('get1newsfeeds:', get1newsfeeds)
    console.log(data);
    
    if (data != null) {
      this.arr = data[0];
      console.log('array data:', this.arr)
      console.log(this.currentDate);
    } else {
    // this.failed()
    }
    }, error => {
    console.log(error);
    });
    }
    onFileChanged(event) {
      this.picture = event.target.files[0];
      console.log("file",this.picture);
      if(event.target.files.length > 0) 
      {
        console.log("filename",event.target.files[0].name);
        this.filename = event.target.files[0].name;
      }
      this.editnewsfeeds.controls['picture'].setValue('../../assets/newsfeedsimg/' + this.filename);
      
      
    }
    fileinput(){
      this.loading = !this.loading;
        console.log("this.file",this.file);
        this.fileUploadService.upload(this.file).subscribe(
            (event: any) => {
                if (typeof (event) === 'object') {
  
                    // Short link via api response
                    this.shortLink = event.link;
  
                    this.loading = false; // Flag variable 
                }
            }
        );
    }
  
    update() {
      this.submitted = true;
      const formatDate1 = formatDate(this.currentDate, 'yyyy-MM-dd  HH:mm:ss' , 'en-US');
      
      // this.submitted = true;
      // if (this.editProductForm.valid) {
      // var veg="false"
      // if(this.editProductForm.value['vegetarian']){
      // veg="true"
      // }
      
      var url = 'https://buddyfind.herokuapp.com/Editnewsfeeds';
      var updateddata = JSON.stringify({
      title: this.editnewsfeeds.value['title'],
      caption:this.editnewsfeeds.value['caption'],
      picture:this.editnewsfeeds.value['picture'],
      createdate:this.editnewsfeeds.value['createdate'],
      editdate:formatDate1,
      idNewsFeeds:this.idNewsFeeds,
      });
      var updatedarrdata = JSON.parse(updateddata);
      
      const httpOptions = {
      headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,HEAD,PUT,PATCH,POST,DELETE'
      })
      };
      this.http.post(url, updatedarrdata, httpOptions).subscribe((data) => {
      console.log("updateddata",updatedarrdata)
      console.log("data",data);
      
      if (data ==true) {
      window.location.reload();
      this.arr = data;
      console.log("data",data);
      } else {
      // this.failed()
      }
      }, error => {
      console.log(error);
      });
      this.router.navigate(['tabs/tab4']);
     }//if valid
     
  }


