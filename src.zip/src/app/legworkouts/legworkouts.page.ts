import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legworkouts',
  templateUrl: './legworkouts.page.html',
  styleUrls: ['./legworkouts.page.scss'],
})
export class LegworkoutsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
