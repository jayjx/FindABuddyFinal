import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-backworkouts',
  templateUrl: './backworkouts.page.html',
  styleUrls: ['./backworkouts.page.scss'],
})
export class BackworkoutsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
