import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-armsworkouts',
  templateUrl: './armsworkouts.page.html',
  styleUrls: ['./armsworkouts.page.scss'],
})
export class ArmsworkoutsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
