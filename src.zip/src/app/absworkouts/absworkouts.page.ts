import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-absworkouts',
  templateUrl: './absworkouts.page.html',
  styleUrls: ['./absworkouts.page.scss'],
})
export class AbsworkoutsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
