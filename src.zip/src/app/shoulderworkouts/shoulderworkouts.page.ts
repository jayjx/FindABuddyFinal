import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shoulderworkouts',
  templateUrl: './shoulderworkouts.page.html',
  styleUrls: ['./shoulderworkouts.page.scss'],
})
export class ShoulderworkoutsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
